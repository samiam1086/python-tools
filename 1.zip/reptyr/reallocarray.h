#ifndef __reallocarray_h
#define __reallocarray_h

void * xreallocarray(void *optr, size_t nmemb, size_t size);

#endif

